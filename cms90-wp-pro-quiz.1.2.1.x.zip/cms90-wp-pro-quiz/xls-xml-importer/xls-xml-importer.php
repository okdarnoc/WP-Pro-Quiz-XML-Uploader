<?php
require_once __DIR__ .'/vendor/autoload.php';
require_once __DIR__ .'/quiz_xls_file_to_xml_file.php';
require_once __DIR__ .'/officedata_xml_file_to_quiz_xml_file.php';
