<?php
function quiz_xls_file_to_xml_file($in_xls_file, $out_xml_file){
  $result=true;
  try {
    $inputFileName = $in_xls_file;
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($inputFileName);
    $reader->setReadDataOnly(TRUE);
    $spreadsheet = $reader->load($inputFileName);

    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray();

    $answer_template=file_get_contents(__DIR__ . '/template/answer.xml');
    $question_template=file_get_contents(__DIR__ . '/template/question.xml');
    $quiz_template=file_get_contents(__DIR__ . '/template/quiz.xml');

    $header=array_flip($rows[0]);
    $quiz=[
      'category'=>$rows[1][$header['Category']],
      'title'=>$rows[1][$header['quiz name']],
      'text'=>$rows[1][$header['quiz name']],
      'questions'=>rows_to_questions_xml($rows, $question_template, $answer_template),
    ];

    $quiz_xml=$quiz_template;
    foreach ($quiz as $quiz_key => $quiz_value) {
      $quiz_xml=str_replace('{'.$quiz_key.'}',$quiz_value,$quiz_xml);
    }

    file_put_contents($out_xml_file, $quiz_xml);
  } catch (Exception $e) {
    ob_start();
    print_r($e);
    echo PHP_EOL;
    echo PHP_EOL;
    echo PHP_EOL;
    echo PHP_EOL;
    $data1=ob_get_clean();
    file_put_contents(dirname(__FILE__)  . '/e.log',$data1,FILE_APPEND);
    $result=false;
  }

  return $result;
}

function rows_to_questions_xml($rows, $question_template, $answer_template){
  $header=$rows[0];
  $header=array_flip($header);
  unset($rows[0]);//remove first row
  $question_xml=[];
  
  foreach ($rows as $key => $question) {
      $ans_header_keys=[
        'a'=>'Option (a)',
        'b'=>'Option (b)',
        'c'=>'Option (c)',
        'd'=>'Option (d)',
        'e'=>'Option (e)',
      ];
      $answer=[];
      foreach ($ans_header_keys as $ah_key => $ah_value) {
        $option_text=$question[$header[$ah_value]];
        if(empty($option_text)){
          continue;
        }
        $answer[$ah_key]=$option_text;
      }
      $correct_answer=$question[$header['Answer']];
      $correct_answer=strtolower($correct_answer);

      $answer_xml=[];
      foreach ($answer as $a_key => $a_value) {
          $answer_correct='false';
          if(strpos($correct_answer,$a_key) !== false){
            $answer_correct='true';
          }
          $ans=[
            'answer_correct'=>$answer_correct,
            'answer_text'=>$a_value
          ];
          $ans_xml=$answer_template;
          foreach ($ans as $ans_key => $ans_value) {
            $ans_xml=str_replace('{'.$ans_key.'}',$ans_value,$ans_xml);
          }
          $answer_xml[]=$ans_xml;
      }

      $qst=[
        'answer_type'=>$question[$header['Answer Type']],
        'title'=>$question[$header['Title']],
        'question_text'=>$question[$header['Question']],
        'category'=>$question[$header['Category']],
        'points'=>empty(intval($question[$header['Points']])) ? 1 : $question[$header['Points']],
        'correct_msg'=>$question[$header['Instruction']],
        'incorrect_msg'=>$question[$header['Incorrect  Answer Message']],
        'tip_msg'=>$question[$header['Hint Message']],
        'answers'=>implode(PHP_EOL,$answer_xml),
      ];

      $qst_xml=$question_template;
      foreach ($qst as $qst_key => $qst_value) {
        $qst_xml=str_replace('{'.$qst_key.'}',$qst_value,$qst_xml);
      }
      $question_xml[]=$qst_xml;      
  }

  $result=implode(PHP_EOL,$question_xml);
  return $result;
}