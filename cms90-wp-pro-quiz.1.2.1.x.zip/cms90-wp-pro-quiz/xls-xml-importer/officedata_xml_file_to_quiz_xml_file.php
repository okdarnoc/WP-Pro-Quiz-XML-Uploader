<?php
function officedata_xml_file_to_quiz_xml_file($in_officedata_xml_file, $out_quiz_xml_file){
    try {
      $content=trim(file_get_contents($in_officedata_xml_file));
      $xml = @simplexml_load_string($content, 'SimpleXMLElement', LIBXML_NOCDATA);

      if ($xml === false) {
        return false;
      }

      if (isset($xml->data)) {//we don't do converting for native quiz xml file
        return false;
      }
      //begin the convert process
      $answer_template=file_get_contents(__DIR__ . '/template/answer.xml');
      $question_template=file_get_contents(__DIR__ . '/template/question.xml');
      $quiz_template=file_get_contents(__DIR__ . '/template/quiz.xml');

      $first_child=$xml->children()[0];
      $quiz=[
        'category'=>$first_child->Category,
        'title'=>$first_child->quiz_x0020_name,
        'text'=>$first_child->quiz_x0020_name,
        'questions'=>children_to_questions_xml($xml->children(), $question_template, $answer_template),
      ];

      $quiz_xml=$quiz_template;
      foreach ($quiz as $quiz_key => $quiz_value) {
        $quiz_xml=str_replace('{'.$quiz_key.'}',$quiz_value,$quiz_xml);
      }

      file_put_contents($out_quiz_xml_file, $quiz_xml);
      return true;
    } catch (Exception $e) {
      ob_start();
      print_r($e);
      echo PHP_EOL;
      echo PHP_EOL;
      echo PHP_EOL;
      echo PHP_EOL;
      $data1=ob_get_clean();
      file_put_contents(dirname(__FILE__)  . '/e.log',$data1,FILE_APPEND);
    }
    return false;
}

function children_to_questions_xml($children, $question_template, $answer_template){
  // $header=$rows[0];
  // $header=array_flip($header);
  // unset($rows[0]);//remove first row
  $question_xml=[];
  
  foreach ($children as $key => $question) {
      $ans_header_keys=[
        'a'=>'Option_x0020__x0028_a_x0029_',
        'b'=>'Option_x0020__x0028_b_x0029_',
        'c'=>'Option_x0020__x0028_c_x0029_',
        'd'=>'Option_x0020__x0028_d_x0029_',
        'e'=>'Option_x0020__x0028_e_x0029_',
      ];
      $answer=[];
      foreach ($ans_header_keys as $ah_key => $ah_value) {
        $option_text=$question->$ah_value;
        if(empty($option_text)){
          continue;
        }
        $answer[$ah_key]=$option_text;
      }
      $correct_answer=$question->Answer;
      $correct_answer=strtolower($correct_answer);

      $answer_xml=[];
      foreach ($answer as $a_key => $a_value) {
          $answer_correct='false';
          if(strpos($correct_answer,$a_key) !== false){
            $answer_correct='true';
          }
          $ans=[
            'answer_correct'=>$answer_correct,
            'answer_text'=>$a_value
          ];
          $ans_xml=$answer_template;
          foreach ($ans as $ans_key => $ans_value) {
            $ans_xml=str_replace('{'.$ans_key.'}',$ans_value,$ans_xml);
          }
          $answer_xml[]=$ans_xml;
      }

      $qst=[
        'answer_type'=>$question->Answer_x0020_Type,
        'title'=>$question->Title,
        'question_text'=>$question->Question,
        'category'=>$question->Category,
        'points'=>empty(intval($question->Points)) ? 1 : $question->Points,
        'correct_msg'=>$question->Instruction,
        'incorrect_msg'=>$question->Incorrect,
        'tip_msg'=>$question->Hint_x0020_Message,
        'answers'=>implode(PHP_EOL,$answer_xml),
      ];

      $qst_xml=$question_template;
      foreach ($qst as $qst_key => $qst_value) {
        $qst_xml=str_replace('{'.$qst_key.'}',$qst_value,$qst_xml);
      }
      $question_xml[]=$qst_xml;      
  }

  $result=implode(PHP_EOL,$question_xml);
  return $result;
}